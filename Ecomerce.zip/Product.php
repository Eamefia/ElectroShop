<?php
// include header.php file
include ("header.php");
?>

<?php
/* include product*/
include ("Template/_product.php");
/* emd include product*/

/* include top-sale*/
include ("Template/_top-sale.php");
/* emd include top-sale*/
?>

<?php
// include footer.php file
include ("footer.php");
?>
