
<html>
<body>
<form action="upload.php" method="post" enctype="multipart/form-data">
    <input type="file" name="files[]" multiple>
    <button type="submit" name="child">send all</button>
</form>

</body>
</html>
